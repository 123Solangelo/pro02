function press3() {
    window.location.href = "../index.html";
   }
 
   function press4() {
     window.location.href = "../html/about me.html";
    } 